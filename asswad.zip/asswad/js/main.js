function formvalidatefunc()                                    
{ 
    var fname = document.forms["RegForm"]["F-Name"];       
    var lname = document.forms["RegForm"]["L-Name"]; 	
    var email = document.forms["RegForm"]["E-Mail"];    
    

    
	
    if (fname.value == "" && fname.value.length<50)                                  
    { 
        window.alert("Please enter your name."); 
        name.focus(); 
		//document.forms("First Name").style.fontSize = "small";
        return false; 
    } 
	
	
    if (lname.value == "" && fname.value.length<50)                                  
    { 
        window.alert("Please enter your name."); 
        name.focus(); 
        return false; 
    } 
   
  
    
    if (email.value == "")                                   
    { 
        window.alert("Please enter a valid e-mail address."); 
        email.focus(); 
        return false; 
    } 
    
	//Other way to validate the email address
    /*
	if (email.value.indexOf("@", 0) < 0)                 
    { 
        window.alert("Please enter a valid e-mail address."); 
        email.focus(); 
        return false; 
    } 
   
    if (email.value.indexOf(".", 0) < 0)                 
    { 
        window.alert("Please enter a valid e-mail address."); 
        email.focus(); 
        return false; 
    } */
	
	if (!validateEmail(email.value))                                  
    { 
        window.alert("Please enter valid email."); 
        email.focus(); 
        return false; 
    }
   
   

function validateEmail(email) 
{
    var re = /\S+@\S+/;
    return re.test(email);
}

return true;
}