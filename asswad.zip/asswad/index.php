<!DOCTYPE html>
<html lang="en">
<head>
	<title>WAD-H UCP Assignment 2</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap4.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
	<script src="js/main.js"></script> 
</head>
<body>


<div class="whole" style='width: 0px auto; margin:0px auto'> 
<div class="row bar" >
<div class="col-5 info">
  UCP JOHAR TOWN | CONTACT US ON:+92 0006485
  </div>
  
  <div class="col-7 teaminfo">
  
  TEAM | FAQ &nbsp &nbsp &bbsp
  
  <img src ="f.jpg" width="20" height="20">
  <img src ="t.jpg" width="20" height="20">
  <img src ="w.jpg" width="20" height="20">
  
  
 </div>
 </div>

 
  <div class= "row text">

 <div class="col-5 logo">
 
 <img src ="logo.jpg" >
 
 </div>
 
  <div class="col-7 text-right">
  
   <div class="dropdown">
 <p> Home &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp </p>
  <div class="dropdown-content">
    <a href="#">Menu</a>
	<br>
    <a href="#">Contact</a>
    
  </div>
 </div>
 <div class="dropdown">
 <p> Pages &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp </p>
  <div class="dropdown-content">
    <a href="#">Menu</a>
	<br>
    <a href="#">Contact</a>
    
  </div>
 </div>
 <div class="dropdown">
 <p> Portfolios &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp </p>
  <div class="dropdown-content">
    <a href="#">Menu</a>
	<br>
    <a href="#">Contact</a>
    
  </div>
 </div>
 
 <div class="dropdown">
 <p> Blog &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp </p>
  <div class="dropdown-content">
    <a href="#">Menu</a>
	<br>
    <a href="#">Contact</a>
    
  </div>
 </div>
 
 
 <div class="dropdown">
 <p> Shop &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp </p>
  <div class="dropdown-content">
    <a href="#">Menu</a>
	<br>
    <a href="#">Contact</ a>
    
  </div>
 </div>
  
</div>


 </div>
 
 <div class="container">
 <div class="row what">
 <div class="col-12 wha" >
        <center>
      <h4>    <i> <b>WHAT I CAN DO</b></i></h4>
	  </center>
 </div>
 </div>
 
 
 </div>
 
 
 
 <div class="container">
 <div class="row test">
 <div class="col-3 res">
 <b><i>FULLY RESPONSIVE</b></i>
 <p> Vivamus elementum semper nisi.Aenean
 vulputate eleifend tellus.Aenean leo ligula,
 porttitor eu,consequent vitae aenean 
 vulputate.</p>
 </div>
 
 <div class="col-3 pow">
 <b><i>POWERFULL PORTFOLIOS</b></i>
 <p> Vivamus elementum semper nisi.Aenean
 vulputate eleifend tellus.Aenean leo ligula,
 porttitor eu,consequent vitae aenean 
 vulputate.</p>
</div>

 <div class="col-3 amz">
 <b><i>AMAZING SHORTCODES</b></i>
 <p> Vivamus elementum semper nisi.Aenean
 vulputate eleifend tellus.Aenean leo ligula,
 porttitor eu,consequent vitae aenean 
 vulputate.</p>
 </div>
 

 </div>
 </div>
 
 
  <div class="container">
 <div class="row what">
 <div class="col-12 wha" >
        <center>
      <h4><i> <b>A LITTLE BIT ABOUT ME</b></i></h4>
	  </center>
 </div>
 </div>
 
 
 </div>
 
   <div class="container">
 <div class="row me">
 
 <div class="col-4 pic">
 
 <img src="pici.jpg" width="300" height="400">
 
 </div>


 
 <div class="col-5 abme">
 
<p> Writing an  page or section for your portfolio, website,
 or blog is never easy. But, the good news is, if you follow the formula and tips below,
 you should be able to generate an engaging  statement without too much of a struggle.</p>
 Here is how to write an  page you can be proud of.
 <br>
 <p>
 
 Your page should convey who you are and what you are doing, how you got there, and where you are looking to go next.
 The following exercises can be helpful in figuring all of that out.
 Spend about five minutes on each question. You can use the answers to give you an idea of what that answer might
 sound like in its final form but be sure to use your own words. 
 What are you currently doing (in regard to your career) and how did you get there? 
 How does your background make you unique?
 Madison is a director of brand marketing, with experience managing global teams and multi-million-dollar campaigns. 
 Her background in brand strategy, visual design, and account management inform her mindful but competitive approach.
 In terms of the work you do, what aspects are you most passionate about and why?
Madison is fueled by her passion for understanding the nuances of cross-cultural advertising. She considers herself a eager to both build on her academic foundations in psychology and sociology and stay in tune with the latest digital marketing strategies through continued coursework.
</p>
<br>


RESUME
<br>
 <p>
 <img src ="f.jpg" width="20" height="20">
  <img src ="t.jpg" width="20" height="20">
  <img src ="w.jpg" width="20" height="20">
  </p>
 
 
 </div>
  </div>
</div>
<div class="row s">
<div class="col-12 say">
<b> Say Hello</b>


</div>
</div>




<div class="row a">
<div class="col-1 p">
</div>

<div class="col-5 add">
Add a Comment
<br>
<br>
<form name="RegForm" action="output.php" onsubmit="return formvalidatefunc()" method="post">  
			<div class="form-group row"> 
				<label  style="font-size:60%" class="col-sm-2 col-form-label">FirstName</label>
				<div class="col-sm-4">
					<input type="text" size=50 name="F-Name" class="form-control">
				</div>
				
				
				<label  style="font-size:60%" class="col-sm-2 col-form-label">LastName</label>
				<div class="col-sm-4">
					<input type="text" size=50 name="L-Name" class="form-control">
				</div>
			</div>		
			
			
			<div class="form-group row"> 
				<label style="font-size:60%" class="col-sm-2 col-form-label">E-mail</label>
				<div class="col-sm-10">
					<input type="text" size=50 name="E-Mail" class="form-control" >
				</div>
			</div>
			
			<div class="form-group row"> 
				<label style="font-size:60%" class="col-sm-2 col-form-label">Message</label>
				<div class="col-sm-10">
					<textarea cols="100" name="Message" class="form-control" ></textarea>
				</div>
				
			</div>
			
			<div class="form-group row">				
				<div class="col-sm-2">
					<button type="submit" name="Submit" class="btn btn-primary">Submit</button>
				</div>
				</div>
			
			
</form>
</div>


<div class="col-4 con">

<p style="font-size:200%"> Content info </p>

<p style="font-size:100%"> The Contact Us page is one of the most visited pages on any website.
That seems like a compelling enough reason to redesign your Contacts section to better meet your users needs and grab their attention.
While working on this post, I came across hundreds of beautifully made websites, yet their Contact Us pages were, for the most part, disappointing.
Most Contact pages are made for show, with just an email address, phone, location, and some short boring text on a plain background.</p>
<br>
<b> Address:</b>Ucp Johar Town,Lahore.
<br>
<b> Mobile:</b>+92000997.
<br>
<b>Mobile1:</b>+920088765.
<br>
<b>E-mail:</b>ashuumalik@ucp.edu.pk.
</div>
<div class="col-1 p">
</div>
  
 </div>
 
 
 <footer class="row foot">
	<div class="col-3 ab">
	<b><p style="color:white"> About </p></b>
	
<p style="color:LightGrey"> BSCS 5th semester Student. </p>	


<input type="text" placeholder="Search..">
</div>

<div class="col-3 ab">
	<b><p style="color:white"> Contact me </p></b>
<p style="color:LightGrey"> Facebook </p>	
<p style="color:LightGrey"> Twitter </p>
<p style="color:LightGrey"> Insta </p>
</div>

<div class="col-3 ab">
	<b><p style="color:white">Additional Links </p></b>
<p style="color:LightGrey"> Projects </p>	
<p style="color:LightGrey"> Pages </p>
<p style="color:LightGrey"> Shop </p>
</div>

<div class="col-3 ab">
	<b><p style="color:white">Contact Me </p></b>
<p style="color:LightGrey"> Ucp Johar Town, Lahore </p>	
<p style="color:LightGrey"> Mobile:+92000887 </p>
<p style="color:LightGrey"> Mobile1:+927765800 </p>
</div>


</footer>
 
 
 </div>
</body>
</html>
